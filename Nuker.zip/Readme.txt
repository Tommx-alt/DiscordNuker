To make the .exe work, you need to open your cmd with CTRL + R, ten type cmd.
Once you open your cmd type 'python -m pip install requests' (with out the '').
============================================================================================
Anything should work, but if you put your tok3n and it crash, do this:

1. Make sure that u have installed the requests. To check it, open your cmd and type 'pip show requests'.

2. Try to restart the .exe and if it still doesn't work, restart your pc, sometimes it works.

Credit:

https://discord.gg/pUkAkSaAmf
https://discord.gg/pUkAkSaAmf
https://discord.gg/pUkAkSaAmf
https://discord.gg/pUkAkSaAmf
https://discord.gg/pUkAkSaAmf